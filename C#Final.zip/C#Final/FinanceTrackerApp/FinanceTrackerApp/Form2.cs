﻿using System;
using System.IO;
using System.Windows.Forms;

namespace FinanceTrackerApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadTransactions();
        }

        // Function to load transactions from the file and display them
        private void LoadTransactions()
        {
            try
            {
                string[] transactions = File.ReadAllLines("transactions.txt");
                foreach (string transaction in transactions)
                {
                    lstTransactions.Items.Add(transaction);
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Error reading transactions file.");
            }
        }
    }
}