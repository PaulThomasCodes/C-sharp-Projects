﻿namespace TravelJournalApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpJournal;
        private System.Windows.Forms.TextBox txtJournalEntry;
        private System.Windows.Forms.Button btnSaveJournal;
        private System.Windows.Forms.Button btnLoadJournal;
        private System.Windows.Forms.ListBox lstJournalEntries;
        private System.Windows.Forms.GroupBox grpSettings;
        private System.Windows.Forms.Label lblThemeInfo;
        private System.Windows.Forms.ComboBox cmbThemeColor;
        private System.Windows.Forms.Button btnSaveSettings;
        private System.Windows.Forms.Button btnLoadSettings;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpJournal = new System.Windows.Forms.GroupBox();
            this.txtJournalEntry = new System.Windows.Forms.TextBox();
            this.btnSaveJournal = new System.Windows.Forms.Button();
            this.btnLoadJournal = new System.Windows.Forms.Button();
            this.lstJournalEntries = new System.Windows.Forms.ListBox();
            this.grpSettings = new System.Windows.Forms.GroupBox();
            this.lblThemeInfo = new System.Windows.Forms.Label();
            this.cmbThemeColor = new System.Windows.Forms.ComboBox();
            this.btnSaveSettings = new System.Windows.Forms.Button();
            this.btnLoadSettings = new System.Windows.Forms.Button();
            this.grpJournal.SuspendLayout();
            this.grpSettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(120, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(340, 32);
            this.lblTitle.Text = "Welcome to Your Travel Journal!";
            // 
            // grpJournal
            // 
            this.grpJournal.Controls.Add(this.txtJournalEntry);
            this.grpJournal.Controls.Add(this.btnSaveJournal);
            this.grpJournal.Controls.Add(this.btnLoadJournal);
            this.grpJournal.Controls.Add(this.lstJournalEntries);
            this.grpJournal.Location = new System.Drawing.Point(20, 60);
            this.grpJournal.Name = "grpJournal";
            this.grpJournal.Size = new System.Drawing.Size(550, 300);
            this.grpJournal.Text = "Journal Entries";
            // 
            // txtJournalEntry
            // 
            this.txtJournalEntry.Location = new System.Drawing.Point(10, 20);
            this.txtJournalEntry.Multiline = true;
            this.txtJournalEntry.Name = "txtJournalEntry";
            this.txtJournalEntry.Size = new System.Drawing.Size(350, 120);
            // 
            // btnSaveJournal
            // 
            this.btnSaveJournal.Location = new System.Drawing.Point(370, 20);
            this.btnSaveJournal.Name = "btnSaveJournal";
            this.btnSaveJournal.Size = new System.Drawing.Size(150, 30);
            this.btnSaveJournal.Text = "Save Entry";
            this.btnSaveJournal.Click += new System.EventHandler(this.BtnSaveJournal_Click);
            // 
            // btnLoadJournal
            // 
            this.btnLoadJournal.Location = new System.Drawing.Point(370, 60);
            this.btnLoadJournal.Name = "btnLoadJournal";
            this.btnLoadJournal.Size = new System.Drawing.Size(150, 30);
            this.btnLoadJournal.Text = "Load Entries";
            this.btnLoadJournal.Click += new System.EventHandler(this.BtnLoadJournal_Click);
            // 
            // lstJournalEntries
            // 
            this.lstJournalEntries.FormattingEnabled = true;
            this.lstJournalEntries.ItemHeight = 15;
            this.lstJournalEntries.Location = new System.Drawing.Point(10, 150);
            this.lstJournalEntries.Name = "lstJournalEntries";
            this.lstJournalEntries.Size = new System.Drawing.Size(350, 120);
            // 
            // grpSettings
            // 
            this.grpSettings.Controls.Add(this.lblThemeInfo);
            this.grpSettings.Controls.Add(this.cmbThemeColor);
            this.grpSettings.Controls.Add(this.btnSaveSettings);
            this.grpSettings.Controls.Add(this.btnLoadSettings);
            this.grpSettings.Location = new System.Drawing.Point(20, 380);
            this.grpSettings.Name = "grpSettings";
            this.grpSettings.Size = new System.Drawing.Size(550, 140);
            this.grpSettings.Text = "Settings";
            // 
            // lblThemeInfo
            // 
            this.lblThemeInfo.AutoSize = true;
            this.lblThemeInfo.Location = new System.Drawing.Point(10, 30);
            this.lblThemeInfo.Name = "lblThemeInfo";
            this.lblThemeInfo.Size = new System.Drawing.Size(250, 15);
            this.lblThemeInfo.Text = "Select a theme color for your journal app:";
            // 
            // cmbThemeColor
            // 
            this.cmbThemeColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbThemeColor.FormattingEnabled = true;
            this.cmbThemeColor.Items.AddRange(new object[] {
            "LightBlue",
            "LightGreen",
            "LightCoral",
            "WhiteSmoke",
            "Lavender"});
            this.cmbThemeColor.Location = new System.Drawing.Point(270, 27);
            this.cmbThemeColor.Name = "cmbThemeColor";
            this.cmbThemeColor.Size = new System.Drawing.Size(150, 23);
            // 
            // btnSaveSettings
            // 
            this.btnSaveSettings.Location = new System.Drawing.Point(10, 70);
            this.btnSaveSettings.Name = "btnSaveSettings";
            this.btnSaveSettings.Size = new System.Drawing.Size(150, 30);
            this.btnSaveSettings.Text = "Save Settings";
            this.btnSaveSettings.Click += new System.EventHandler(this.BtnSaveSettings_Click);
            // 
            // btnLoadSettings
            // 
            this.btnLoadSettings.Location = new System.Drawing.Point(180, 70);
            this.btnLoadSettings.Name = "btnLoadSettings";
            this.btnLoadSettings.Size = new System.Drawing.Size(150, 30);
            this.btnLoadSettings.Text = "Load Settings";
            this.btnLoadSettings.Click += new System.EventHandler(this.BtnLoadSettings_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 550);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grpJournal);
            this.Controls.Add(this.grpSettings);
            this.Name = "MainForm";
            this.Text = "Travel Journal App";
            this.grpJournal.ResumeLayout(false);
            this.grpJournal.PerformLayout();
            this.grpSettings.ResumeLayout(false);
            this.grpSettings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}