﻿using System;
using System.IO;
using System.Windows.Forms;

namespace MathHelperWithHistory
{
    public partial class MainForm : Form
    {
        // Arrays to store input and result history
        private string[] inputHistory = new string[100];   // array to hold string log entries
        private double[] resultHistory = new double[100];  // array to hold square root results
        private int historyIndex = 0; // tracks the current position in the arrays

        public MainForm()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblResult.Text = "";

            try
            {
                bool isValid = double.TryParse(txtInput.Text, out double number);

                if (!isValid)
                    throw new FormatException("Please enter a valid numeric value.");

                if (number < 0)
                    throw new ArgumentException("Cannot calculate square root of a negative number.");

                double result = Math.Sqrt(number);

                // Save input and result into the arrays
                if (historyIndex < inputHistory.Length)
                {
                    inputHistory[historyIndex] = $"Input: {number}";
                    resultHistory[historyIndex] = result;
                    lstHistory.Items.Add($"√{number} = {result}"); // display in ListBox
                    historyIndex++;
                }

                // Show result to user
                lblResult.Text = $"Result: √{number} = {result}";
            }
            catch (FormatException ex)
            {
                lblError.Text = ex.Message;
            }
            catch (ArgumentException ex)
            {
                lblError.Text = ex.Message;
            }
            catch (Exception ex)
            {
                lblError.Text = "Unexpected error: " + ex.Message;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter("SquareRootHistory.txt"))
                {
                    for (int i = 0; i < historyIndex; i++)
                    {
                        writer.WriteLine($"{inputHistory[i]} => Result: {resultHistory[i]}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving history: " + ex.Message);
            }

            Application.Exit();
        }
    }
}