using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace FinanceTrackerApp
{
    public partial class Form1 : Form
    {
        // Variables for income and expense amounts
        double income = 0;
        double expense = 0;
        double balance = 0;

        public Form1()
        {
            InitializeComponent();
        }

        // Event handler to add income
        private void btnAddIncome_Click(object sender, EventArgs e)
        {
            try
            {
                double amount = Convert.ToDouble(txtAmount.Text);
                income += amount;
                balance += amount;
                WriteTransactionToFile("Income", amount);
                lblBalance.Text = "Balance: $" + balance;
                txtAmount.Clear();
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }

        // Event handler to add expense
        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            try
            {
                double amount = Convert.ToDouble(txtAmount.Text);
                expense += amount;
                balance -= amount;
                WriteTransactionToFile("Expense", amount);
                lblBalance.Text = "Balance: $" + balance;
                txtAmount.Clear();
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }

        // Function to write transaction to the file
        private void WriteTransactionToFile(string type, double amount)
        {
            string transaction = $"{DateTime.Now} - {type}: ${amount}";
            try
            {
                File.AppendAllText("transactions.txt", transaction + Environment.NewLine);
            }
            catch (IOException)
            {
                MessageBox.Show("Error writing to file.");
            }
        }

        // Event handler to show report form
        private void btnViewReport_Click(object sender, EventArgs e)
        {
            Form2 reportForm = new Form2();
            reportForm.Show();
        }
    }
}