using System;
using System.IO;
using System.Windows.Forms;

namespace TravelJournalApp
{
    public partial class MainForm : Form
    {
        // Paths to save journal entries and settings
        private readonly string journalFilePath = "journalEntries.txt";
        private readonly string settingsFilePath = "settings.txt";

        public MainForm()
        {
            InitializeComponent();
        }

        // Save the journal entry to a file
        private void BtnSaveJournal_Click(object sender, EventArgs e)
        {
            // Make sure the user typed something
            if (string.IsNullOrWhiteSpace(txtJournalEntry.Text))
            {
                MessageBox.Show("Please write something before saving!", "Empty Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Save the new journal entry by appending it to the file
                File.AppendAllText(journalFilePath, txtJournalEntry.Text + Environment.NewLine);
                MessageBox.Show("Journal entry saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                txtJournalEntry.Clear(); // Clear the text box after saving
                LoadJournalEntries(); // Refresh the list
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Something went wrong while saving: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Load journal entries from the file and show them in the listbox
        private void BtnLoadJournal_Click(object sender, EventArgs e)
        {
            LoadJournalEntries();
        }

        // Helper method to load journal entries
        private void LoadJournalEntries()
        {
            try
            {
                lstJournalEntries.Items.Clear(); // Clear existing items

                if (File.Exists(journalFilePath))
                {
                    var entries = File.ReadAllLines(journalFilePath);
                    lstJournalEntries.Items.AddRange(entries);
                }
                else
                {
                    MessageBox.Show("No journal entries found yet. Start writing one!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading entries: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Save user-selected theme settings
        private void BtnSaveSettings_Click(object sender, EventArgs e)
        {
            if (cmbThemeColor.SelectedItem == null)
            {
                MessageBox.Show("Please select a theme color first.", "Select a Theme", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                File.WriteAllText(settingsFilePath, cmbThemeColor.SelectedItem.ToString());
                MessageBox.Show("Theme setting saved!", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Load saved theme settings
        private void BtnLoadSettings_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(settingsFilePath))
                {
                    string savedTheme = File.ReadAllText(settingsFilePath);

                    cmbThemeColor.SelectedItem = savedTheme;

                    ApplyTheme(savedTheme);

                    MessageBox.Show($"Theme '{savedTheme}' applied!", "Theme Loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No saved settings found. Save a theme first!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // apply the background color based on the theme
        private void ApplyTheme(string colorName)
        {
            try
            {
                this.BackColor = System.Drawing.Color.FromName(colorName);
            }
            catch
            {
                // If the color isn't valid, we default to White
                this.BackColor = System.Drawing.Color.White;
            }
        }
    }
}