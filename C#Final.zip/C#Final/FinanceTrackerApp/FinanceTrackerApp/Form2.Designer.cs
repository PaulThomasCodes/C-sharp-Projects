﻿namespace FinanceTrackerApp
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListBox lstTransactions;

        private void InitializeComponent()
        {
            this.lstTransactions = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lstTransactions
            // 
            this.lstTransactions.FormattingEnabled = true;
            this.lstTransactions.Location = new System.Drawing.Point(25, 25);
            this.lstTransactions.Name = "lstTransactions";
            this.lstTransactions.Size = new System.Drawing.Size(230, 160);
            this.lstTransactions.TabIndex = 0;
            // 
            // Form2
            // 
            this.ClientSize = new System.Drawing.Size(284, 211);
            this.Controls.Add(this.lstTransactions);
            this.Name = "Form2";
            this.Text = "Transactions Report";
            this.ResumeLayout(false);
        }
    }
}