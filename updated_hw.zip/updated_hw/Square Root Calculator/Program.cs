using System;
using System.Windows.Forms;

namespace MathHelperWithHistory
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Enables visual styles for modern UI appearance
            Application.EnableVisualStyles();

            // Ensures compatibility for text rendering
            Application.SetCompatibleTextRenderingDefault(false);

            // Start the app by opening MainForm
            Application.Run(new MainForm());
        }
    }
}